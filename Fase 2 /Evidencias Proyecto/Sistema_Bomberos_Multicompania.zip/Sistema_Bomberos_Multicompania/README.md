# Inventario y mantenimiento — Bomberos San Bernardo

## Ejecutar

Desde `backend/`:

```powershell
pip install -r requirements.txt
python app.py
```

Abrir `http://127.0.0.1:5000`.

## Alcance

- Inventario de materiales con importación/exportación Excel y alertas.
- Registro de mantenimiento o reparación con costo CLP, kilometraje y horas de uso opcionales.
- Registro separado de gastos por categoría.
- Checklist diario de entrada y salida, sin duplicar mismo carro, fecha y turno.
- Resumen agregado de costos registrados.

## Verificación

Desde `backend/`: `python test_api_final.py` utiliza **una base de datos temporal**, no modifica la base de trabajo. Las funcionalidades de inventario y Excel se probaron manualmente desde el navegador; las pantallas nuevas aún requieren comprobación presencial en el PC del estudiante.

## Límites

- No existe un login con roles; usar solamente en entorno de confianza y acceso local.
- No hay valoración unitaria de cada material ni reporte específico de pérdidas.
- El costo de mantenimiento se registra aparte de las compras, para evitar doble conteo.
- Los registros de mantenimiento no modifican automáticamente las fechas de cada ítem.
- La carga Excel reemplaza el inventario de las unidades contenidas en el archivo, por eso **hacer respaldo antes de importar**.
- Requiere validación institucional antes de cualquier uso operativo.
