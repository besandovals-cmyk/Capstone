// Capa de acceso a la API del backend. Es lo único que "habla" con el servidor.
const API_URL = window.API_URL || '/api';

async function pedir(ruta, opciones) {
  const r = await fetch(API_URL + ruta, opciones);
  if (!r.ok) {
    let msg = 'Error del servidor';
    try { msg = (await r.json()).error || msg; } catch (e) {}
    throw new Error(msg);
  }
  return r.status === 204 ? null : r.json();
}
const enJson = (metodo, cuerpo) => ({ method: metodo, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cuerpo) });

const api = {
  listar: () => pedir('/items'),
  crear: d => pedir('/items', enJson('POST', d)),
  actualizar: (id, d) => pedir('/items/' + id, enJson('PUT', d)),
  borrar: id => pedir('/items/' + id, { method: 'DELETE' }),
  unidades: () => pedir('/unidades'),
  responsable: (u, r) => pedir('/unidades/' + encodeURIComponent(u), enJson('PUT', { responsable: r })),
  importar: f => { const fd = new FormData(); fd.append('archivo', f); return pedir('/importar', { method: 'POST', body: fd }); },
  urlExcel: () => API_URL + '/exportar.xlsx',
  mantenimientos: () => pedir('/mantenimientos'),
  crearMantenimiento: d => pedir('/mantenimientos', enJson('POST', d)),
  gastos: () => pedir('/gastos'),
  crearGasto: d => pedir('/gastos', enJson('POST', d)),
  checklists: () => pedir('/checklist'),
  crearChecklist: d => pedir('/checklist', enJson('POST', d)),
  resumenEconomico: () => pedir('/resumen-economico'),
  login: d => pedir('/login', enJson('POST',d)),
  logout: () => pedir('/logout', enJson('POST',{})),
  yo: () => pedir('/yo'),
  companias: () => pedir('/companias'),
  crearCompania: d => pedir('/companias',enJson('POST',d)),
  elegirCompania: d => pedir('/seleccionar-compania',enJson('POST',d)),
  usuarios: () => pedir('/usuarios'),
  crearUsuario: d => pedir('/usuarios',enJson('POST',d)),
  cambiarUsuario: (id,d) => pedir('/usuarios/'+id,enJson('PUT',d)),
  valorizacion: () => pedir('/valorizacion'),
  perdidas: () => pedir('/perdidas'),
  registrarPerdida: d => pedir('/perdidas',enJson('POST',d)),
  reportePerdidas: () => pedir('/reporte-perdidas')
};
