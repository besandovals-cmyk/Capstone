// Interfaz: dibuja los datos que entrega la API. No contiene reglas de negocio (están en backend/alertas.py).
const CAMPOS = ['unidad', 'item', 'marca', 'modelo', 'serie', 'cantidad', 'valor_unitario', 'ubicacion', 'estado', 'origen', 'observaciones', 'vencimiento', 'ultima_mantencion', 'cada_dias'];
let items = [], unidades = [], editId = null;

const $ = id => document.getElementById(id);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase();
const opts = (id, arr) => { $(id).innerHTML = arr.map(x => `<option value="${esc(x)}">`).join(''); };
const uniq = k => [...new Set(items.map(i => i[k]).filter(v => v && v !== 'N/A'))].sort();

async function cargar() {
  try { [items, unidades] = await Promise.all([api.listar(), api.unidades()]); }
  catch (e) { alert('No se pudo conectar con el servidor: ' + e.message); items = []; unidades = []; }
  render();
  if (typeof cargarExtras==='function') await cargarExtras();
}

function render() {
  const sel = $('flt_unit'), cur = sel.value;
  sel.innerHTML = '<option value="">Todos los carros</option>' + unidades.map(u => `<option${u.nombre === cur ? ' selected' : ''}>${esc(u.nombre)}</option>`).join('');
  opts('dUnit', unidades.map(u => u.nombre)); opts('dUbic', uniq('ubicacion')); opts('dOri', uniq('origen'));
  const q = norm($('q').value), fu = sel.value, fe = $('flt_est').value;
  $('respRow').style.display = fu ? 'flex' : 'none';
  if (fu && document.activeElement.id !== 'respIn') $('respIn').value = (unidades.find(u => u.nombre === fu) || {}).responsable || '';

  const todos = items.filter(i => !fu || i.unidad === fu);
  const lista = todos.filter(i => (fe === 'crit' ? i.nivel === 2 : fe === 'alert' ? i.nivel >= 1 : true) &&
    (!q || norm([i.item, i.marca, i.modelo, i.serie, i.ubicacion, i.estado, i.origen, i.observaciones].join(' ')).includes(q)));

  $('rows').innerHTML = lista.map(i => `<tr class="l${i.nivel}"><td class="n">${i.orden}</td><td class="n">${esc(i.unidad)}</td><td><b>${esc(i.item)}</b></td>
    <td>${esc(i.marca)}<div class="m">${esc(i.modelo)}</div></td><td class="m">${esc(i.serie)}</td><td><b>${i.cantidad}</b></td>
    <td>${moneda(i.valor_unitario)}</td><td>${moneda(i.cantidad*i.valor_unitario)}</td><td>${esc(i.ubicacion)}</td><td>${esc(i.estado)}${i.proximo_control ? `<div class="m">Control: ${esc(i.proximo_control)}</div>` : ''}</td>
    <td class="m">${esc(i.origen)}</td><td>${esc(i.observaciones)}</td>
    <td><span class="tag l${i.nivel}">${['OK', 'Revisar', 'Crítico'][i.nivel]}</span></td>
    <td class="n">${window.usuarioSesionRol==='bombero'?'Solo lectura':`<button onclick="edit(${i.id})">Editar</button> <button class="d" onclick="del(${i.id})">✕</button>`}</td></tr>`).join('');
  $('empty').style.display = lista.length ? 'none' : 'block';

  const crit = todos.filter(i => i.nivel === 2), warn = todos.filter(i => i.nivel === 1);
  const linea = i => `<div class="al l${i.nivel}" onclick="edit(${i.id})"><b>${esc(i.unidad)}</b> · ${esc(i.item)}${i.ubicacion ? ` (${esc(i.ubicacion)})` : ''} — ${esc(i.motivos.join(' · '))}</div>`;
  $('alerts').innerHTML = crit.map(linea).join('') +
    (warn.length ? `<details><summary>⚠️ ${warn.length} ítems por revisar</summary>${warn.map(linea).join('')}</details>` : '') +
    (!crit.length && !warn.length ? '<div class="al l0">✅ Sin alertas.</div>' : '');
  $('sItems').textContent = todos.length;
  $('sUnits').textContent = todos.reduce((a, i) => a + i.cantidad, 0);
  $('sCar').textContent = unidades.length;
  $('sCrit').textContent = crit.length;
  $('sWarn').textContent = warn.length;
}

async function save() {
  const d = {};
  CAMPOS.forEach(k => d[k] = $('f_' + k).value);
  if (!d.item.trim() || !d.unidad.trim()) return alert('Carro/Bodega e Ítem son obligatorios');
  try { editId ? await api.actualizar(editId, d) : await api.crear(d); resetForm(); await cargar(); }
  catch (e) { alert(e.message); }
}
function resetForm() {
  editId = null;
  CAMPOS.forEach(k => $('f_' + k).value = '');
  $('f_cantidad').value = 1;
  $('formTitle').textContent = 'Agregar ítem';
}
function edit(id) {
  const i = items.find(x => x.id === id); if (!i) return;
  editId = id;
  CAMPOS.forEach(k => $('f_' + k).value = (k === 'cada_dias' && !i[k]) ? '' : (i[k] ?? ''));
  $('formTitle').textContent = 'Editando: ' + i.item;
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
async function del(id) {
  const i = items.find(x => x.id === id);
  if (!i || !confirm(`¿Eliminar "${i.item}" de ${i.unidad}?`)) return;
  try { await api.borrar(id); await cargar(); } catch (e) { alert(e.message); }
}
async function setResp() {
  const u = $('flt_unit').value; if (!u) return;
  try { await api.responsable(u, $('respIn').value); await cargar(); } catch (e) { alert(e.message); }
}

async function importar(ev) {
  const f = ev.target.files[0]; ev.target.value = ''; if (!f) return;
  if (!confirm('Se reemplazará el inventario de los carros que vengan en el archivo (los demás no se tocan). ¿Continuar?')) return;
  try {
    const r = await api.importar(f);
    alert('Importado:\n' + Object.entries(r.unidades).map(([u, n]) => `${u}: ${n} ítems`).join('\n'));
    await cargar();
  } catch (e) { alert(e.message); }
}
function exportar() { window.location.href = api.urlExcel(); }

function copyAlerts() {
  let t = `🚒 Alertas de inventario – Bomberos San Bernardo (${new Date().toLocaleDateString('es-CL')})\n`, hay = false;
  unidades.forEach(u => {
    const al = items.filter(i => i.unidad === u.nombre && i.nivel).sort((a, b) => b.nivel - a.nivel);
    if (!al.length) return;
    hay = true;
    t += `\n*${u.nombre}*${u.responsable ? ` (Resp.: ${u.responsable})` : ''}\n` + al.map(i => `${i.nivel === 2 ? '🚨' : '⚠️'} ${i.item} – ${i.motivos.join(', ')}`).join('\n') + '\n';
  });
  if (!hay) t += '\nSin alertas ✅';
  navigator.clipboard.writeText(t).then(() => alert('Alertas copiadas'), () => prompt('Copia el texto:', t));
}

// El inicio se realiza después de validar la sesión en acceso.js.
