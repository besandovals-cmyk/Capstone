// Autenticación en el servidor: las restricciones se verifican también en Flask.
let usuarioSesion=null;
const campo=id=>document.getElementById(id);
async function iniciarSesion(){
  try {
    await api.login({usuario:campo('loginUsuario').value,contrasena:campo('loginPassword').value});
    campo('loginPassword').value='';await abrirAplicacion();
  } catch(e) {campo('loginError').textContent=e.message;}
}
async function abrirAplicacion(){
  const r=await api.yo();usuarioSesion=r.usuario;window.usuarioSesionRol=r.usuario.rol;
  campo('pantallaLogin').style.display='none';campo('aplicacion').style.display='block';
  campo('usuarioActual').textContent=`${r.usuario.nombre} · ${r.usuario.rol} · ${r.compania?.nombre||''}`;
  campo('panelAdmin').style.display=r.usuario.rol==='admin'?'block':'none';
  document.querySelectorAll('.gestion-card').forEach(el=>el.style.display=r.usuario.rol==='bombero'?'none':'block');
  if(r.usuario.rol==='bombero'){
    document.querySelectorAll('button[onclick^="save("],button[onclick^="importar("],button[onclick^="exportar("],button[onclick^="guardarMantenimiento("],button[onclick^="guardarGasto("],button[onclick^="setResp("]').forEach(b=>b.disabled=true);
    campo('formTitle').closest('.card').style.display='none';
    campo('operacion').style.display='none';
  }
  await cargar();await cargarOperaciones();
  if(r.usuario.rol==='admin')await cargarAdministracion();
}
async function cerrarSesion(){await api.logout();window.location.reload();}
async function cargarAdministracion(){
 const [co,usuarios]=await Promise.all([api.companias(),api.usuarios()]);
 const actual=(await api.yo()).compania.id;
 campo('companiaActiva').innerHTML=co.map(c=>`<option value="${c.id}" ${c.id===actual?'selected':''}>${esc(c.nombre)}</option>`).join('');
 campo('u_compania').innerHTML=co.map(c=>`<option value="${c.id}">${esc(c.nombre)}</option>`).join('');
 campo('listaUsuarios').innerHTML='<h3>Usuarios registrados</h3>'+usuarios.map(u=>`<div style="padding:6px;border-bottom:1px solid #ddd">${esc(u.username)} · ${esc(u.nombre)} · ${esc(u.rol)} · Compañía ${u.compania_id||'global'} · ${u.activo?'Activo':'Inactivo'} <button onclick="cambiarEstadoUsuario(${u.id},${u.activo?0:1})">${u.activo?'Desactivar':'Activar'}</button> <button onclick="restablecerClave(${u.id})">Cambiar clave</button></div>`).join('');
}
async function cambiarEstadoUsuario(id,activo){
 try{await api.cambiarUsuario(id,{activo:Boolean(activo)});await cargarAdministracion();}catch(e){alert(e.message)}
}
async function restablecerClave(id){
 const pw=prompt('Nueva contraseña para este usuario (mínimo 12 caracteres):');if(pw===null)return;
 try{await api.cambiarUsuario(id,{contrasena:pw});alert('Clave actualizada.');}catch(e){alert(e.message)}
}
async function cambiarCompania(){
 try{await api.elegirCompania({compania_id:Number(campo('companiaActiva').value)});await abrirAplicacion();}catch(e){alert(e.message);}
}
async function agregarCompania(){
 try{await api.crearCompania({nombre:campo('nuevaCompania').value});campo('nuevaCompania').value='';await cargarAdministracion();alert('Compañía creada.');}catch(e){alert(e.message)}
}
async function agregarUsuario(){
 try{await api.crearUsuario({nombre:campo('u_nombre').value,usuario:campo('u_usuario').value,
 contrasena:campo('u_contrasena').value,rol:campo('u_rol').value,compania_id:Number(campo('u_compania').value)});
 campo('u_contrasena').value='';await cargarAdministracion();alert('Usuario creado.');}catch(e){alert(e.message)}
}
async function cargarExtras(){
 if(!usuarioSesion)return;
 try{
  const [v,p]=await Promise.all([api.valorizacion(),api.reportePerdidas()]);
  campo('resumenValorizacion').textContent=`${v.registros} registros · ${v.unidades} unidades · ${v.con_precio||0} con precio · Valor registrado: ${moneda(v.valor_total)} CLP`;
  campo('listaPerdidas').innerHTML=`<p><b>Valor histórico de pérdidas: ${moneda(p.total_perdido)}</b></p>`+
   (p.registros.length?`<div class="mini-tabla"><table><tr><th>Fecha</th><th>Carro</th><th>Artículo</th><th>Cant.</th><th>Valor pérdida</th><th>Motivo</th></tr>${p.registros.map(x=>`<tr><td>${esc(x.fecha)}</td><td>${esc(x.unidad)}</td><td>${esc(x.item)}</td><td>${x.cantidad}</td><td>${moneda(x.valor_total)}</td><td>${esc(x.motivo)}</td></tr>`).join('')}</table></div>`:'<p>Aún no hay pérdidas registradas.</p>');
  campo('p_item_id').innerHTML=items.filter(i=>i.cantidad>0).map(i=>`<option value="${i.id}">${esc(i.unidad)} - ${esc(i.item)} (${i.cantidad})</option>`).join('');
 }catch(e){console.error('No se pudieron cargar valoraciones',e)}
}
async function registrarPerdida(){
 try{await api.registrarPerdida({item_id:Number(campo('p_item_id').value),fecha:campo('p_fecha').value,
 cantidad:Number(campo('p_cantidad').value),motivo:campo('p_motivo').value,responsable:campo('p_responsable').value,
 observaciones:campo('p_observaciones').value});await cargar();alert('Pérdida registrada y existencia descontada.');}
 catch(e){alert(e.message)}
}
async function descargarReportePerdidas(){
 try{
 const d=await api.reportePerdidas();
 const cols=['fecha','unidad','item','cantidad','valor_unitario','valor_total','motivo','responsable','observaciones'];
 const cell=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
 const csv='\uFEFF'+[cols.join(';'),...d.registros.map(x=>cols.map(k=>cell(x[k])).join(';'))].join('\r\n');
 const blob=new Blob([csv],{type:'text/csv;charset=utf-8'});const url=URL.createObjectURL(blob);
 const a=document.createElement('a');a.href=url;a.download='reporte_perdidas.csv';a.click();URL.revokeObjectURL(url);
 }catch(e){alert(e.message)}
}
campo('p_fecha').value=new Date().toLocaleDateString('en-CA');
campo('loginPassword').addEventListener('keydown',e=>{if(e.key==='Enter')iniciarSesion()});
api.yo().then(()=>abrirAplicacion()).catch(()=>{campo('pantallaLogin').style.display='flex'});
