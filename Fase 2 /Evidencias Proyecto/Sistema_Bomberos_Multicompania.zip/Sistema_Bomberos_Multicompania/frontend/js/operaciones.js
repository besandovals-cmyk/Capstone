// Formularios de los módulos complementarios. Los datos quedan en SQLite.
const moneda = n => '$' + Number(n || 0).toLocaleString('es-CL');
const valor = id => document.getElementById(id).value.trim();
const campos = pref => Object.fromEntries([...document.querySelectorAll(`[id^="${pref}_"]`)].map(el => [el.id.slice(2), el.value]));
function tabla(id, columnas, filas) {
  const cont=document.getElementById(id);
  cont.innerHTML = filas.length ? `<table><thead><tr>${columnas.map(c=>`<th>${c[0]}</th>`).join('')}</tr></thead><tbody>${filas.map(f=>`<tr>${columnas.map(c=>`<td>${esc(c[1](f))}</td>`).join('')}</tr>`).join('')}</tbody></table>` : '<p class="muted">Aún no hay registros en este módulo.</p>';
}
async function cargarOperaciones(){
  try {
    const [m,g,c,r] = await Promise.all([api.mantenimientos(),api.gastos(),api.checklists(),api.resumenEconomico()]);
    tabla('listaMantenimientos', [['Fecha',x=>x.fecha],['Carro',x=>x.unidad],['Tipo',x=>x.tipo],['Descripción',x=>x.descripcion],['Costo CLP',x=>moneda(x.costo)]],m);
    tabla('listaGastos', [['Fecha',x=>x.fecha],['Carro',x=>x.unidad],['Concepto',x=>x.concepto],['Monto CLP',x=>moneda(x.monto)]],g);
    tabla('listaChecklists', [['Fecha',x=>x.fecha],['Carro',x=>x.unidad],['Turno',x=>x.turno],['Responsable',x=>x.responsable],['Equipos',x=>x.equipos_ok?'Sí':'No']],c);
    document.getElementById('totalGasto').textContent='Total registrado (gastos y mantenciones): '+moneda(r.total);
  } catch (e) {console.error('No se pudieron cargar módulos complementarios',e)}
}
async function guardarMantenimiento(){
  const d=campos('m'); if(!d.unidad||!d.fecha||!d.descripcion)return alert('Completa carro, fecha y descripción.');
  try {await api.crearMantenimiento(d);document.getElementById('m_descripcion').value='';await cargarOperaciones();alert('Mantenimiento registrado.');}catch(e){alert(e.message)}
}
async function guardarGasto(){
  const d=campos('g');if(!d.unidad||!d.fecha||!d.concepto)return alert('Completa carro, fecha y concepto.');
  try {await api.crearGasto(d);document.getElementById('g_concepto').value='';await cargarOperaciones();alert('Gasto registrado.');}catch(e){alert(e.message)}
}
async function guardarChecklist(){
  const d=campos('c');if(!d.unidad||!d.fecha||!d.responsable)return alert('Completa carro, fecha y responsable.');
  d.equipos_ok=Boolean(Number(d.equipos_ok));
  try {await api.crearChecklist(d);await cargarOperaciones();alert('Checklist registrado.');}catch(e){alert(e.message)}
}
// Fechas del día como valores predeterminados, sin crear registros ficticios.
const hoy = new Date().toLocaleDateString('en-CA');
['m_fecha','g_fecha','c_fecha'].forEach(id=>{document.getElementById(id).value=hoy;});
cargarOperaciones();
