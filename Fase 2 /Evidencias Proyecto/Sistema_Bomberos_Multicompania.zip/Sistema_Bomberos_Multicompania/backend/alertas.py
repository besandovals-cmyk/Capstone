"""Reglas de negocio: calcula el nivel de alerta de cada ítem.
nivel 0 = OK, 1 = revisar, 2 = crítico."""
import re, unicodedata
from datetime import date, timedelta

def norm(s):
    s = unicodedata.normalize("NFD", str(s or ""))
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn").upper()

def proximo_control(i):
    """Última mantención + periodicidad; si no hay, usa el vencimiento fijo."""
    if i["ultima_mantencion"] and (i["cada_dias"] or 0) > 0:
        try:
            return (date.fromisoformat(i["ultima_mantencion"]) + timedelta(days=int(i["cada_dias"]))).isoformat()
        except ValueError:
            pass
    return i["vencimiento"] or ""

def evaluar(i):
    estado, obs = norm(i["estado"]), norm(i["observaciones"])
    res = {"nivel": 0, "motivos": []}
    def add(n, texto):
        res["motivos"].append(texto)
        res["nivel"] = max(res["nivel"], n)

    if "VENCID" in estado: add(2, "Vencido")
    if re.search(r"MAL[OA]", estado): add(2, "Estado malo")
    if "BAJA" in estado + " " + obs: add(2, "Propuesto para baja")
    if (i["cantidad"] or 0) <= 0: add(2, "Sin existencias")

    prox = proximo_control(i)
    if prox:
        try:
            dias = (date.fromisoformat(prox) - date.today()).days
            if dias < 0: add(2, f"Control vencido hace {-dias} días")
            elif dias <= 30: add(1, f"Control en {dias} días")
        except ValueError:
            pass
    if "REGULAR" in estado: add(1, "Estado regular")
    if re.search(r"SIN PILAS|FALTA|QUEBRAD|CORTAD|NO CORTA|RAYAD|SIN PROTEC|MANTENC|DANAD|ROTO", obs):
        add(1, i["observaciones"])
    res["proximo_control"] = prox
    return res
