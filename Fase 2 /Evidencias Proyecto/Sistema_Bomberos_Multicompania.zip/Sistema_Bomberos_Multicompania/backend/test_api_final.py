"""Prueba aislada del sistema: python test_api_final.py. Nunca toca inventario.db."""
import os, tempfile
from pathlib import Path
with tempfile.TemporaryDirectory(prefix='bomberos_test_') as folder:
    os.environ['INVENTARIO_DB'] = str(Path(folder)/'prueba.db')
    from app import app
    app.testing = True
    c=app.test_client()
    r=c.get('/api/items')
    assert r.status_code==200 and len(r.get_json())==229
    datos={'unidad':'CARRO B-6','fecha':'2026-10-15','tipo':'Correctiva','descripcion':'Prueba aislada','costo':25000}
    assert c.post('/api/mantenimientos',json=datos).status_code==201
    gasto={'unidad':'CARRO B-6','fecha':'2026-10-15','concepto':'Prueba de gasto','monto':1200}
    assert c.post('/api/gastos',json=gasto).status_code==201
    assert c.get('/api/resumen-economico').get_json()['total']==26200
    check={'unidad':'CARRO B-6','fecha':'2026-10-15','turno':'Entrada','responsable':'Prueba','equipos_ok':True}
    assert c.post('/api/checklist',json=check).status_code==201
    assert c.post('/api/checklist',json=check).status_code==409
    assert c.post('/api/gastos',json={**gasto,'monto':-1}).status_code==400
    assert len(c.get('/api/items').get_json())==229
    print('8 comprobaciones completadas en BD temporal. Inventario de trabajo sin cambios.')
