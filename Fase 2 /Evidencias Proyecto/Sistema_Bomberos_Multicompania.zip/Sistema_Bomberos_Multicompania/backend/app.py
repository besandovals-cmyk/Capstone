"""API REST del inventario. Ejecutar:  python app.py  (http://localhost:5000)"""
import os
from datetime import date, datetime
from flask import Flask, jsonify, request, send_file, send_from_directory, session, g
import alertas, db, excel_io, sqlite3
from werkzeug.security import check_password_hash, generate_password_hash

FRONTEND = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend")
TEXTO = ["unidad", "item", "marca", "modelo", "serie", "ubicacion", "estado", "origen",
         "observaciones", "vencimiento", "ultima_mantencion"]
NUMERO = ["cantidad", "cada_dias", "valor_unitario"]

app = Flask(__name__, static_folder=None)
app.config.update(SECRET_KEY=os.environ.get('INVENTARIO_SECRET_KEY') or os.urandom(32),
                  SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
                  PERMANENT_SESSION_LIFETIME=__import__('datetime').timedelta(hours=8))
db.init()
excel_io.sembrar_si_vacio()

# No se habilita CORS abierto: las sesiones funcionan únicamente en mismo origen.
@app.after_request
def cabeceras(r):
    r.headers['X-Content-Type-Options'] = 'nosniff'
    r.headers['X-Frame-Options'] = 'DENY'
    r.headers['Cache-Control'] = 'no-store' if request.path.startswith('/api/') else 'no-cache'
    return r

def compania_actual():
    if g.usuario['rol']=='admin':
        return int(session.get('compania_id',1))
    return int(g.usuario['compania_id'])

def puede_editar():
    return g.usuario['rol'] in ('admin','encargado')

@app.before_request
def proteger():
    if not request.path.startswith('/api/') or request.path in ('/api/login','/api/logout'):
        return
    uid=session.get('uid')
    if not uid:
        return jsonify(error='Debes iniciar sesión.'),401
    with db.conn() as c:
        user=c.execute('SELECT id,username,nombre,rol,compania_id,activo FROM usuarios WHERE id=?',(uid,)).fetchone()
    if not user or not user['activo']:
        session.clear(); return jsonify(error='Acceso no autorizado.'),401
    g.usuario=dict(user)
    if g.usuario['rol']!='admin' and session.get('compania_id') != g.usuario['compania_id']:
        session['compania_id']=g.usuario['compania_id']
    if request.method not in ('GET','HEAD','OPTIONS'):
        # La misma interfaz y el servidor deben compartir origen.
        origen=request.headers.get('Origin')
        if origen:
            from urllib.parse import urlsplit
            if urlsplit(origen).netloc != request.host:
                return jsonify(error='Origen no permitido.'),403
        if not request.is_json and request.path!='/api/importar':
            return jsonify(error='Se requiere solicitud JSON.'),415
        # Operadores pueden registrar checklists, pero no modificar inventario ni costos.
        if not puede_editar() and not (request.path=='/api/checklist' and request.method=='POST'):
            return jsonify(error='No tienes permisos para esta operación.'),403

@app.post('/api/login')
def login():
    d=request.get_json(silent=True) or {}
    username=str(d.get('usuario','')).strip().lower()
    password=str(d.get('contrasena',''))
    if not username or not password:
        return jsonify(error='Usuario y contraseña obligatorios.'),400
    with db.conn() as c:
        u=c.execute('SELECT * FROM usuarios WHERE username=? AND activo=1',(username,)).fetchone()
    if not u or not check_password_hash(u['password_hash'],password):
        return jsonify(error='Credenciales incorrectas.'),401
    session.clear();session.permanent=True;session['uid']=u['id']
    session['compania_id']=u['compania_id'] or 1
    return jsonify(ok=True)

@app.post('/api/logout')
def logout():
    session.clear();return jsonify(ok=True)

@app.get('/api/yo')
def yo():
    with db.conn() as c:
        co=c.execute('SELECT id,nombre FROM companias WHERE id=?',(compania_actual(),)).fetchone()
    return jsonify(usuario=g.usuario,compania=dict(co) if co else None)

@app.get('/api/companias')
def companias():
    with db.conn() as c:
        if g.usuario['rol']=='admin':
            return jsonify([dict(x) for x in c.execute('SELECT * FROM companias ORDER BY id')])
        return jsonify([dict(x) for x in c.execute('SELECT * FROM companias WHERE id=?',(compania_actual(),))])

@app.post('/api/companias')
def crear_compania():
    if g.usuario['rol']!='admin':return jsonify(error='Solo administrador general.'),403
    d=_datos();nombre=_texto(d,'nombre',True)
    try:
        with db.conn() as c:
            cur=c.execute('INSERT INTO companias(nombre) VALUES(?)',(nombre,))
            return jsonify(id=cur.lastrowid,nombre=nombre),201
    except sqlite3.IntegrityError:return jsonify(error='Esa compañía ya existe.'),409

@app.post('/api/seleccionar-compania')
def seleccionar_compania():
    if g.usuario['rol']!='admin':return jsonify(error='Solo administrador general.'),403
    n=_entero(_datos().get('compania_id'),'compania_id')
    with db.conn() as c:
        if not c.execute('SELECT 1 FROM companias WHERE id=?',(n,)).fetchone():return jsonify(error='Compañía inexistente.'),404
    session['compania_id']=n
    return jsonify(ok=True)

@app.get('/api/usuarios')
def usuarios():
    if g.usuario['rol']!='admin':return jsonify(error='Solo administrador general.'),403
    with db.conn() as c:
        return jsonify([dict(r) for r in c.execute('SELECT id,username,nombre,rol,compania_id,activo FROM usuarios ORDER BY id')])

@app.post('/api/usuarios')
def crear_usuario():
    if g.usuario['rol']!='admin':return jsonify(error='Solo administrador general.'),403
    d=_datos();nom=_texto(d,'nombre',True);usuario=_texto(d,'usuario',True).lower();password=str(d.get('contrasena') or '')
    rol=_texto(d,'rol',True)
    if rol not in ('admin','encargado','bombero'):raise ValueError('Rol no válido.')
    if len(password)<12:raise ValueError('Contraseña: mínimo 12 caracteres.')
    co=None if rol=='admin' else _entero(d.get('compania_id'),'compania_id')
    with db.conn() as c:
        if rol!='admin' and (not co or not c.execute('SELECT 1 FROM companias WHERE id=?',(co,)).fetchone()):raise ValueError('Compañía inexistente.')
        try:
            cur=c.execute('INSERT INTO usuarios(username,password_hash,nombre,rol,compania_id) VALUES(?,?,?,?,?)',
                          (usuario,generate_password_hash(password),nom,rol,co))
        except sqlite3.IntegrityError:return jsonify(error='El usuario ya existe.'),409
    return jsonify(id=cur.lastrowid,usuario=usuario),201

def limpiar(d):
    if not isinstance(d, dict):
        raise ValueError("El contenido debe ser un objeto JSON.")
    o = {k: str(d.get(k) if d.get(k) is not None else "").strip() for k in TEXTO}
    o["unidad"] = o["unidad"].upper()
    for k in NUMERO:
        valor = d.get(k, 0)
        if valor in (None, ""):
            valor = 0
        try:
            n = int(valor)
        except (TypeError, ValueError):
            raise ValueError(f"{k}: ingresa un número entero válido.")
        if n < 0:
            raise ValueError(f"{k}: no puede ser negativo.")
        o[k] = n
    for campo in ("vencimiento", "ultima_mantencion"):
        if o[campo]:
            try:
                date.fromisoformat(o[campo])
            except ValueError:
                raise ValueError(f"{campo}: usa el formato AAAA-MM-DD.")
    return o

@app.errorhandler(ValueError)
def error_datos(e):
    return jsonify(error=str(e)), 400


def con_alerta(r):
    d = dict(r)
    d.update(alertas.evaluar(d))
    return d

@app.put('/api/usuarios/<int:id>')
def modificar_usuario(id):
    if g.usuario['rol']!='admin':return jsonify(error='Solo administrador general.'),403
    d=_datos()
    with db.conn() as c:
        u=c.execute('SELECT id,rol,activo FROM usuarios WHERE id=?',(id,)).fetchone()
        if not u:return jsonify(error='Usuario inexistente.'),404
        if 'activo' in d:
            if d['activo'] not in (True,False):raise ValueError('activo: usa true o false.')
            if id==g.usuario['id'] and not d['activo']:
                raise ValueError('No puedes desactivar tu propia cuenta.')
            c.execute('UPDATE usuarios SET activo=? WHERE id=?',(int(d['activo']),id))
        if 'contrasena' in d:
            pw=str(d['contrasena'])
            if len(pw)<12:raise ValueError('Contraseña: mínimo 12 caracteres.')
            c.execute('UPDATE usuarios SET password_hash=? WHERE id=?',(generate_password_hash(pw),id))
    return jsonify(ok=True)

@app.get("/api/items")
def listar():
    with db.conn() as c:
        return jsonify([con_alerta(r) for r in c.execute("SELECT * FROM items WHERE compania_id=? ORDER BY unidad, orden",(compania_actual(),))])

@app.post("/api/items")
def crear():
    o = limpiar(request.get_json(force=True))
    if not o["unidad"] or not o["item"]:
        return jsonify(error="Carro/Bodega e Ítem son obligatorios"), 400
    with db.conn() as c:
        o["orden"] = c.execute("SELECT COALESCE(MAX(orden),0)+1 FROM items WHERE unidad=? AND compania_id=?", (o["unidad"],compania_actual())).fetchone()[0]
        o['compania_id']=compania_actual()
        c.execute('INSERT OR IGNORE INTO compania_unidades(compania_id,nombre) VALUES(?,?)',(compania_actual(),o['unidad']))
        cols = list(o)
        cur = c.execute(f"INSERT INTO items ({','.join(cols)}) VALUES ({','.join('?'*len(cols))})", [o[k] for k in cols])
        return jsonify(con_alerta(c.execute("SELECT * FROM items WHERE id=? AND compania_id=?", (cur.lastrowid,compania_actual())).fetchone())), 201

@app.put("/api/items/<int:id>")
def actualizar(id):
    o = limpiar(request.get_json(force=True))
    if not o["unidad"] or not o["item"]:
        return jsonify(error="Carro/Bodega e Ítem son obligatorios"), 400
    with db.conn() as c:
        ant = c.execute("SELECT unidad FROM items WHERE id=? AND compania_id=?", (id,compania_actual())).fetchone()
        if not ant: return jsonify(error="No existe"), 404
        if ant["unidad"] != o["unidad"]:
            o["orden"] = c.execute("SELECT COALESCE(MAX(orden),0)+1 FROM items WHERE unidad=? AND compania_id=?", (o["unidad"],compania_actual())).fetchone()[0]
        c.execute(f"UPDATE items SET {','.join(k+'=?' for k in o)} WHERE id=? AND compania_id=?", [*o.values(), id,compania_actual()])
        return jsonify(con_alerta(c.execute("SELECT * FROM items WHERE id=? AND compania_id=?", (id,compania_actual())).fetchone()))

@app.delete("/api/items/<int:id>")
def borrar(id):
    with db.conn() as c:
        if c.execute('SELECT 1 FROM perdidas WHERE item_id=? AND compania_id=?',(id,compania_actual())).fetchone():
            return jsonify(error='El artículo tiene pérdidas registradas; no puedes eliminar su historial.'),409
        c.execute("DELETE FROM items WHERE id=? AND compania_id=?", (id,compania_actual()))
    return "", 204

@app.get('/api/unidades')
def unidades():
    with db.conn() as c:
        return jsonify([dict(r) for r in c.execute('SELECT nombre,responsable FROM compania_unidades WHERE compania_id=? ORDER BY nombre',(compania_actual(),))])

@app.put('/api/unidades/<nombre>')
def responsable(nombre):
    r=str((_datos()).get('responsable','')).strip()
    with db.conn() as c:
        c.execute('INSERT INTO compania_unidades(compania_id,nombre,responsable) VALUES(?,?,?) ON CONFLICT(compania_id,nombre) DO UPDATE SET responsable=excluded.responsable',
                  (compania_actual(),nombre.upper(),r))
    return jsonify(nombre=nombre.upper(),responsable=r)

@app.post("/api/importar")
def importar():
    f = request.files.get("archivo")
    if not f: return jsonify(error="Falta el archivo"), 400
    try:
        conteo = excel_io.importar(f,compania_actual())
    except (ValueError, OSError, KeyError) as e:
        return jsonify(error=str(e)), 400
    return jsonify(unidades=conteo)

@app.get("/api/exportar.xlsx")
def exportar():
    return send_file(excel_io.exportar(compania_actual()), as_attachment=True, download_name=f"inventario_bomberos_{date.today()}.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

# Registros complementarios: mantenciones, costos y checklist diario.
def _fecha(v):
    s = str(v or '').strip()
    try: return date.fromisoformat(s).isoformat()
    except ValueError: raise ValueError('Fecha inválida: usa AAAA-MM-DD.')

def _entero(v, campo, opcional=False):
    if opcional and (v is None or str(v).strip() == ''): return None
    try:
        if isinstance(v, bool): raise ValueError()
        n = int(v)
        if str(v).strip() != str(n): raise ValueError()
    except (TypeError, ValueError): raise ValueError(f'{campo}: ingresa un número entero.')
    if n < 0: raise ValueError(f'{campo}: no puede ser negativo.')
    return n

def _texto(d, campo, obligatorio=False):
    v = str(d.get(campo) or '').strip()
    if obligatorio and not v: raise ValueError(f'{campo}: campo obligatorio.')
    if len(v) > 1000: raise ValueError(f'{campo}: supera el límite de caracteres.')
    return v

def _datos():
    d = request.get_json(silent=True)
    if not isinstance(d, dict): raise ValueError('Envía datos JSON válidos.')
    return d

@app.get('/api/mantenimientos')
def mantenimientos_listar():
    with db.conn() as c:
        return jsonify([dict(r) for r in c.execute('SELECT * FROM mantenimientos WHERE compania_id=? ORDER BY fecha DESC,id DESC',(compania_actual(),))])

@app.post('/api/mantenimientos')
def mantenimientos_crear():
    d = _datos()
    o = dict(unidad=_texto(d,'unidad',True).upper(), item_id=_entero(d.get('item_id'),'item_id',True),
             fecha=_fecha(d.get('fecha')), tipo=_texto(d,'tipo',True),
             descripcion=_texto(d,'descripcion',True), costo=_entero(d.get('costo',0),'costo'),
             kilometraje=_entero(d.get('kilometraje'),'kilometraje',True),
             horas_uso=None, responsable=_texto(d,'responsable'))
    if str(d.get('horas_uso','')).strip():
        try: o['horas_uso'] = float(d['horas_uso'])
        except (ValueError, TypeError): raise ValueError('horas_uso: valor inválido.')
        if not 0 <= o['horas_uso'] < 1e9: raise ValueError('horas_uso: fuera de rango.')
    o['compania_id']=compania_actual()
    with db.conn() as c:
        if o['item_id'] is not None and not c.execute('SELECT 1 FROM items WHERE id=? AND unidad=? AND compania_id=?',(o['item_id'],o['unidad'],compania_actual())).fetchone():
            raise ValueError('El artículo no pertenece al carro elegido.')
        keys=list(o); cur=c.execute(f"INSERT INTO mantenimientos ({','.join(keys)}) VALUES ({','.join('?' for _ in keys)})",[o[k] for k in keys])
        return jsonify(dict(c.execute('SELECT * FROM mantenimientos WHERE id=? AND compania_id=?',(cur.lastrowid,compania_actual())).fetchone())),201

@app.get('/api/gastos')
def gastos_listar():
    with db.conn() as c:
        return jsonify([dict(r) for r in c.execute('SELECT * FROM movimientos_gasto WHERE compania_id=? ORDER BY fecha DESC,id DESC',(compania_actual(),))])

@app.post('/api/gastos')
def gastos_crear():
    d=_datos()
    o=dict(fecha=_fecha(d.get('fecha')), unidad=_texto(d,'unidad',True).upper(),
           concepto=_texto(d,'concepto',True), categoria=_texto(d,'categoria') or 'Otro',
           monto=_entero(d.get('monto'),'monto'), observaciones=_texto(d,'observaciones'))
    o['compania_id']=compania_actual()
    with db.conn() as c:
        keys=list(o); cur=c.execute(f"INSERT INTO movimientos_gasto ({','.join(keys)}) VALUES ({','.join('?' for _ in keys)})", [o[k] for k in keys])
        return jsonify(dict(c.execute('SELECT * FROM movimientos_gasto WHERE id=? AND compania_id=?',(cur.lastrowid,compania_actual())).fetchone())),201

@app.get('/api/checklist')
def checklist_listar():
    with db.conn() as c:
        return jsonify([dict(r) for r in c.execute('SELECT * FROM checklist WHERE compania_id=? ORDER BY fecha DESC,id DESC',(compania_actual(),))])

@app.post('/api/checklist')
def checklist_crear():
    d=_datos(); turno=_texto(d,'turno',True).capitalize()
    if turno not in ('Entrada','Salida'): raise ValueError('turno: debe ser Entrada o Salida.')
    if d.get('equipos_ok') not in (True,False,0,1): raise ValueError('equipos_ok: selecciona Sí o No.')
    o=dict(fecha=_fecha(d.get('fecha')), unidad=_texto(d,'unidad',True).upper(),
           turno=turno, responsable=_texto(d,'responsable',True), combustible=_texto(d,'combustible'),
           kilometraje=_entero(d.get('kilometraje'),'kilometraje',True),
           equipos_ok=int(d['equipos_ok']), observaciones=_texto(d,'observaciones'))
    o['compania_id']=compania_actual()
    try:
        with db.conn() as c:
            keys=list(o);cur=c.execute(f"INSERT INTO checklist ({','.join(keys)}) VALUES ({','.join('?' for _ in keys)})",[o[k] for k in keys])
            return jsonify(dict(c.execute('SELECT * FROM checklist WHERE id=? AND compania_id=?',(cur.lastrowid,compania_actual())).fetchone())),201
    except __import__('sqlite3').IntegrityError:
        return jsonify(error='Ya existe un checklist de ese carro, fecha y turno.'),409

@app.get('/api/resumen-economico')
def resumen_economico():
    with db.conn() as c:
        gasto=c.execute('SELECT COALESCE(SUM(monto),0) FROM movimientos_gasto WHERE compania_id=?',(compania_actual(),)).fetchone()[0]
        mantenimiento=c.execute('SELECT COALESCE(SUM(costo),0) FROM mantenimientos WHERE compania_id=?',(compania_actual(),)).fetchone()[0]
        return jsonify(gastos=int(gasto), mantenimientos=int(mantenimiento), total=int(gasto+mantenimiento),
                       nota='Son dos registros separados. Evita ingresar un mismo costo en ambos módulos.')

@app.get('/api/valorizacion')
def valorizacion():
    with db.conn() as c:
        r=c.execute('SELECT COUNT(*) registros,COALESCE(SUM(cantidad),0) unidades,COALESCE(SUM(cantidad*valor_unitario),0) valor_total, SUM(CASE WHEN valor_unitario>0 THEN 1 ELSE 0 END) con_precio FROM items WHERE compania_id=?',(compania_actual(),)).fetchone()
        return jsonify(dict(r))

@app.get('/api/perdidas')
def listar_perdidas():
    with db.conn() as c:
        return jsonify([dict(r) for r in c.execute('SELECT p.*,i.item, i.unidad FROM perdidas p JOIN items i ON p.item_id=i.id WHERE p.compania_id=? ORDER BY p.fecha DESC,p.id DESC',(compania_actual(),))])

@app.post('/api/perdidas')
def registrar_perdida():
    d=_datos(); iid=_entero(d.get('item_id'),'item_id');cant=_entero(d.get('cantidad'),'cantidad')
    if cant<1:raise ValueError('Cantidad: mínimo 1.')
    motivo=_texto(d,'motivo',True);resp=_texto(d,'responsable',True)
    fecha=_fecha(d.get('fecha'))
    with db.conn() as c:
        row=c.execute('SELECT id,cantidad,valor_unitario FROM items WHERE id=? AND compania_id=?',(iid,compania_actual())).fetchone()
        if not row: return jsonify(error='Artículo inexistente en tu compañía.'),404
        if cant>row['cantidad']:raise ValueError('La pérdida supera la cantidad disponible.')
        c.execute('UPDATE items SET cantidad=cantidad-? WHERE id=? AND compania_id=?',(cant,iid,compania_actual()))
        cur=c.execute('INSERT INTO perdidas(compania_id,item_id,fecha,cantidad,valor_unitario,motivo,responsable,observaciones,registrado_por) VALUES(?,?,?,?,?,?,?,?,?)',
                      (compania_actual(),iid,fecha,cant,row['valor_unitario'],motivo,resp,_texto(d,'observaciones'),g.usuario['id']))
        return jsonify(dict(c.execute('SELECT * FROM perdidas WHERE id=?',(cur.lastrowid,)).fetchone())),201

@app.get('/api/reporte-perdidas')
def reporte_perdidas():
    with db.conn() as c:
        filas=[dict(r) for r in c.execute('SELECT p.*,i.item,i.unidad,p.cantidad*p.valor_unitario AS valor_total FROM perdidas p JOIN items i ON i.id=p.item_id WHERE p.compania_id=? ORDER BY p.fecha DESC',(compania_actual(),))]
    return jsonify(registros=filas,total_perdido=sum(f['valor_total'] for f in filas))

@app.get("/")
def inicio():
    return send_from_directory(FRONTEND, "index.html")

@app.get("/<path:ruta>")
def estaticos(ruta):
    return send_from_directory(FRONTEND, ruta)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
