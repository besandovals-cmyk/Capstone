"""Pruebas verificables sin depender de Flask. Ejecutar: python -m unittest test_revision.py"""
import os
import tempfile
import unittest
from io import BytesIO
from pathlib import Path
from openpyxl import Workbook
import alertas
import db
import excel_io

class RevisionInventario(unittest.TestCase):
    def setUp(self):
        self._old = db.RUTA_DB
        self.tmp = tempfile.TemporaryDirectory()
        db.RUTA_DB = str(Path(self.tmp.name) / 'prueba.db')
        db.init()

    def tearDown(self):
        db.RUTA_DB = self._old
        self.tmp.cleanup()

    def test_planilla_original(self):
        datos = Path(__file__).parent / 'datos' / 'PLANILLA_INVENTARIO_SEXTA_CBSB.xlsx'
        filas, _ = excel_io.leer(datos)
        self.assertEqual(len(filas), 229)
        self.assertEqual(sum(alertas.evaluar(f)['nivel'] == 2 for f in filas), 5)
        self.assertEqual(sum(alertas.evaluar(f)['nivel'] == 1 for f in filas), 36)

    def test_importar_y_exportar(self):
        path = Path(__file__).parent / 'datos' / 'PLANILLA_INVENTARIO_SEXTA_CBSB.xlsx'
        conteo = excel_io.importar(path)
        self.assertEqual(sum(conteo.values()), 229)
        with db.conn() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM items').fetchone()[0], 229)
        contenido = excel_io.exportar()
        self.assertGreater(len(contenido.read()), 1000)
        contenido.seek(0)
        filas, _ = excel_io.leer(contenido)
        self.assertEqual(len(filas), 229)

    def test_archivo_invalido_no_borra_datos(self):
        path = Path(__file__).parent / 'datos' / 'PLANILLA_INVENTARIO_SEXTA_CBSB.xlsx'
        excel_io.importar(path)
        wb = Workbook()
        wb.active.append(['No es una planilla de inventario'])
        buf = BytesIO()
        wb.save(buf)
        buf.seek(0)
        with self.assertRaises(ValueError):
            excel_io.importar(buf)
        with db.conn() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM items').fetchone()[0], 229)

    def test_alertas(self):
        i = {'estado':'Bueno', 'observaciones':'', 'cantidad':1, 'ultima_mantencion':'', 'cada_dias':0, 'vencimiento':''}
        self.assertEqual(alertas.evaluar(i)['nivel'], 0)
        i['cantidad'] = 0
        self.assertEqual(alertas.evaluar(i)['nivel'], 2)

if __name__ == '__main__':
    unittest.main()
