"""Ejecutar una sola vez: python crear_admin.py"""
import getpass, sqlite3
from werkzeug.security import generate_password_hash
import db

db.init()
with db.conn() as c:
    if c.execute('SELECT COUNT(*) FROM usuarios WHERE rol="admin"').fetchone()[0]:
        raise SystemExit('Ya existe un administrador. No se creará otro desde la consola.')
usuario=input('Usuario administrador: ').strip().lower()
nombre=input('Nombre del administrador: ').strip()
password=getpass.getpass('Contraseña (mínimo 12 caracteres): ')
confirmar=getpass.getpass('Confirmar contraseña: ')
if len(password)<12 or password!=confirmar or not usuario or not nombre:
    raise SystemExit('Datos inválidos o contraseñas distintas. No se creó el usuario.')
with db.conn() as c:
    c.execute('INSERT INTO usuarios(username,nombre,password_hash,rol) VALUES (?,?,?,?)',
              (usuario,nombre,generate_password_hash(password),'admin'))
print('Administrador creado. Inicia la aplicación con python app.py')
