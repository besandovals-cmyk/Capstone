"""Pruebas automatizadas del sistema multi-compañía sobre DB temporal.
Ejecutar: python test_multi.py (requiere dependencias instaladas).
"""
import os, tempfile, unittest
from pathlib import Path

DB_TEMP=tempfile.TemporaryDirectory(prefix='bomberos_test_')
os.environ['INVENTARIO_DB']=str(Path(DB_TEMP.name)/'test.db')
import app, db
from werkzeug.security import generate_password_hash

class PruebasMultiCompania(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with db.conn() as c:
            c.execute('INSERT INTO companias(nombre) VALUES(?)',('Segunda Compañía Test',))
            cls.second=c.execute('SELECT id FROM companias WHERE nombre=?',('Segunda Compañía Test',)).fetchone()[0]
            for usuario,rol,cid in [('admin','admin',None),('encargado1','encargado',1),('bombero2','bombero',cls.second),('encargado2','encargado',cls.second)]:
                c.execute('INSERT INTO usuarios(username,nombre,password_hash,rol,compania_id) VALUES (?,?,?,?,?)',
                          (usuario,usuario,generate_password_hash('ContraseñaFuerte123!'),rol,cid))
        cls.app=app.app
        cls.app.config['TESTING']=True

    def cliente(self,usuario):
        client=self.app.test_client()
        r=client.post('/api/login',json={'usuario':usuario,'contrasena':'ContraseñaFuerte123!'})
        self.assertEqual(r.status_code,200,r.get_json())
        return client

    def test_01_sin_sesion(self):
        self.assertEqual(self.app.test_client().get('/api/items').status_code,401)

    def test_02_login_incorrecto(self):
        self.assertEqual(self.app.test_client().post('/api/login',json={'usuario':'admin','contrasena':'incorrecta'}).status_code,401)

    def test_03_migracion(self):
        c=self.cliente('encargado1')
        self.assertEqual(len(c.get('/api/items').get_json()),229)

    def test_04_aislamiento(self):
        c1=self.cliente('encargado1');c2=self.cliente('encargado2')
        item=c1.get('/api/items').get_json()[0]
        self.assertEqual(c2.get('/api/items').get_json(),[])
        self.assertEqual(c2.delete(f'/api/items/{item["id"]}').status_code,204)
        self.assertEqual(len(c1.get('/api/items').get_json()),229)

    def test_05_operador_solo_checklist(self):
        c=self.cliente('bombero2')
        self.assertEqual(c.post('/api/gastos',json={}).status_code,403)
        self.assertEqual(c.get('/api/usuarios').status_code,403)
        r=c.post('/api/checklist',json={'fecha':'2026-10-15','unidad':'CARRO Z-1','turno':'Entrada','responsable':'Test','equipos_ok':True})
        self.assertEqual(r.status_code,201,r.get_json())

    def test_06_admin_compania(self):
        c=self.cliente('admin')
        r=c.post('/api/seleccionar-compania',json={'compania_id':self.second})
        self.assertEqual(r.status_code,200,r.get_json())
        self.assertEqual(c.get('/api/items').get_json(),[])

    def test_07_valorizacion_y_perdida(self):
        c=self.cliente('encargado2')
        d={'unidad':'CARRO Z-1','item':'Equipo Prueba','cantidad':3,'valor_unitario':10000}
        r=c.post('/api/items',json=d);self.assertEqual(r.status_code,201,r.get_json())
        iid=r.get_json()['id'];self.assertEqual(c.get('/api/valorizacion').get_json()['valor_total'],30000)
        r=c.post('/api/perdidas',json={'item_id':iid,'fecha':'2026-10-15','cantidad':1,'motivo':'Prueba','responsable':'Inspector'})
        self.assertEqual(r.status_code,201,r.get_json())
        self.assertEqual(c.get('/api/valorizacion').get_json()['valor_total'],20000)
        self.assertEqual(c.get('/api/reporte-perdidas').get_json()['total_perdido'],10000)
        self.assertEqual(c.delete(f'/api/items/{iid}').status_code,409)
        self.assertEqual(c.post('/api/perdidas',json={'item_id':iid,'fecha':'2026-10-15','cantidad':10,'motivo':'Error','responsable':'Inspector'}).status_code,400)

    def test_08_no_cruzar_empresa_por_id(self):
        c2=self.cliente('encargado2');c1=self.cliente('encargado1')
        original=c1.get('/api/items').get_json()[0]
        self.assertEqual(c2.put(f'/api/items/{original["id"]}',json={'unidad':'CARRO B-6','item':'Hack'}).status_code,404)
        self.assertEqual(c2.post('/api/perdidas',json={'item_id':original['id'],'cantidad':1,'fecha':'2026-10-15','motivo':'Error','responsable':'X'}).status_code,404)

    def test_09_importar_exportar_aislado(self):
        c=self.cliente('encargado2')
        r=c.get('/api/exportar.xlsx');self.assertEqual(r.status_code,200)
        from io import BytesIO
        import excel_io
        rows,_=excel_io.leer(BytesIO(r.data))
        self.assertTrue(rows)
        self.assertTrue(all(x['unidad']=='CARRO Z-1' for x in rows))

if __name__=='__main__':
    try:unittest.main(verbosity=2)
    finally:DB_TEMP.cleanup()
