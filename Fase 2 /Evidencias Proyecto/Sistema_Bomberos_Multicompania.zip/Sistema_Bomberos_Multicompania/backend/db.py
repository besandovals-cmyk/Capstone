"""Base de datos SQLite: conexión y creación de tablas."""
import os, sqlite3

RUTA_DB = os.environ.get("INVENTARIO_DB", os.path.join(os.path.dirname(__file__), "inventario.db"))

def conn():
    c = sqlite3.connect(RUTA_DB)
    c.execute("PRAGMA foreign_keys = ON")
    c.row_factory = sqlite3.Row
    return c

def init():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS unidades (
            nombre TEXT PRIMARY KEY,
            responsable TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            unidad TEXT NOT NULL,
            orden INTEGER DEFAULT 0,
            item TEXT NOT NULL,
            marca TEXT DEFAULT '', modelo TEXT DEFAULT '', serie TEXT DEFAULT '',
            cantidad INTEGER DEFAULT 1,
            ubicacion TEXT DEFAULT '', estado TEXT DEFAULT '', origen TEXT DEFAULT '',
            observaciones TEXT DEFAULT '',
            vencimiento TEXT DEFAULT '',
            ultima_mantencion TEXT DEFAULT '',
            cada_dias INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS mantenimientos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            unidad TEXT NOT NULL,
            item_id INTEGER,
            fecha TEXT NOT NULL,
            tipo TEXT NOT NULL,
            descripcion TEXT NOT NULL,
            costo INTEGER NOT NULL DEFAULT 0 CHECK(costo >= 0),
            kilometraje INTEGER,
            horas_uso REAL,
            responsable TEXT DEFAULT '',
            FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE SET NULL
        );
        CREATE TABLE IF NOT EXISTS movimientos_gasto (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT NOT NULL,
            unidad TEXT NOT NULL,
            concepto TEXT NOT NULL,
            categoria TEXT DEFAULT 'Otro',
            monto INTEGER NOT NULL CHECK(monto >= 0),
            observaciones TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS checklist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT NOT NULL,
            unidad TEXT NOT NULL,
            turno TEXT NOT NULL CHECK(turno IN ('Entrada', 'Salida')),
            responsable TEXT NOT NULL,
            combustible TEXT NOT NULL DEFAULT '',
            kilometraje INTEGER,
            equipos_ok INTEGER NOT NULL CHECK(equipos_ok IN (0,1)),
            observaciones TEXT DEFAULT '',
            UNIQUE(fecha, unidad, turno)
        );
        """)

        # Migración conservadora: mantiene registros existentes en compañía inicial.
        c.executescript("""
        CREATE TABLE IF NOT EXISTS companias (
          id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL UNIQUE, activa INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS usuarios (
          id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL, nombre TEXT NOT NULL, rol TEXT NOT NULL
          CHECK(rol IN ('admin','encargado','bombero')),
          compania_id INTEGER REFERENCES companias(id), activo INTEGER NOT NULL DEFAULT 1,
          CHECK((rol='admin' AND compania_id IS NULL) OR (rol!='admin' AND compania_id IS NOT NULL))
        );
        CREATE TABLE IF NOT EXISTS compania_unidades (
          compania_id INTEGER NOT NULL REFERENCES companias(id), nombre TEXT NOT NULL,
          responsable TEXT DEFAULT '', PRIMARY KEY(compania_id,nombre)
        );
        CREATE TABLE IF NOT EXISTS perdidas (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          compania_id INTEGER NOT NULL REFERENCES companias(id),
          item_id INTEGER NOT NULL REFERENCES items(id), fecha TEXT NOT NULL,
          cantidad INTEGER NOT NULL CHECK(cantidad > 0), valor_unitario INTEGER NOT NULL CHECK(valor_unitario >= 0),
          motivo TEXT NOT NULL, responsable TEXT NOT NULL,
          observaciones TEXT DEFAULT '', registrado_por INTEGER REFERENCES usuarios(id)
        );
        """)
        c.execute("INSERT OR IGNORE INTO companias(id,nombre) VALUES (1,?)",('Bomberos San Bernardo - Compañía inicial',))
        for table in ('items','mantenimientos','movimientos_gasto','checklist'):
            columnas={r['name'] for r in c.execute(f'PRAGMA table_info({table})')}
            if 'compania_id' not in columnas:
                c.execute(f'ALTER TABLE {table} ADD COLUMN compania_id INTEGER REFERENCES companias(id)')
                c.execute(f'UPDATE {table} SET compania_id=1 WHERE compania_id IS NULL')
        columnas={r['name'] for r in c.execute('PRAGMA table_info(items)')}
        if 'valor_unitario' not in columnas:
            c.execute('ALTER TABLE items ADD COLUMN valor_unitario INTEGER NOT NULL DEFAULT 0')
        c.execute('INSERT OR IGNORE INTO compania_unidades(compania_id,nombre,responsable) SELECT 1,nombre,responsable FROM unidades')
        c.execute('INSERT OR IGNORE INTO compania_unidades(compania_id,nombre) SELECT DISTINCT compania_id,unidad FROM items')
        for table in ('items','mantenimientos','movimientos_gasto','checklist'):
            c.execute(f'CREATE INDEX IF NOT EXISTS ix_{table}_compania ON {table}(compania_id)')
        c.execute('CREATE INDEX IF NOT EXISTS ix_perdidas_compania ON perdidas(compania_id)')
        # La tabla checklist antigua tiene una UNIQUE global que impediría revisar
        # el mismo vehículo en dos compañías. Migración reversible en una copia.
        unique_sql=c.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='checklist'").fetchone()[0]
        if 'UNIQUE(fecha, unidad, turno)' in unique_sql:
            c.executescript('''
                CREATE TABLE checklist_nueva (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    fecha TEXT NOT NULL, unidad TEXT NOT NULL,
                    turno TEXT NOT NULL CHECK(turno IN ('Entrada','Salida')),
                    responsable TEXT NOT NULL, combustible TEXT NOT NULL DEFAULT '',
                    kilometraje INTEGER, equipos_ok INTEGER NOT NULL CHECK(equipos_ok IN (0,1)),
                    observaciones TEXT DEFAULT '', compania_id INTEGER REFERENCES companias(id),
                    UNIQUE(compania_id, fecha, unidad, turno)
                );
                INSERT INTO checklist_nueva SELECT id,fecha,unidad,turno,responsable,combustible,kilometraje,equipos_ok,observaciones,compania_id FROM checklist;
                DROP TABLE checklist;
                ALTER TABLE checklist_nueva RENAME TO checklist;
                CREATE INDEX IF NOT EXISTS ix_checklist_compania ON checklist(compania_id);
            ''')
