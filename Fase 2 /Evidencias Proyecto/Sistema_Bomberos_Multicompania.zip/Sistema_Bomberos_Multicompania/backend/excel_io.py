"""Importar / exportar planillas Excel con el formato de Bomberos."""
import glob, os, re
from io import BytesIO
from openpyxl import Workbook, load_workbook
import db

ENCABEZADO = ["N° Orden", "Ítem", "Marca", "Modelo", "N° Serie", "Cantidad", "Ubicación", "Estado",
              "Origen / Financiamiento", "Observaciones", "Próx. control", "Últ. mantención", "Cada (días)", "Valor unitario (CLP)"]

def _t(x):
    if x is None: return ""
    return x.date().isoformat() if hasattr(x, "date") else str(x).strip()

def _n(x):
    try: return int(float(x))
    except (TypeError, ValueError): return 0

def leer(archivo):
    """Devuelve (filas, responsables) desde un .xlsx (ruta o archivo subido)."""
    try:
        wb = load_workbook(archivo, data_only=True)
    except Exception as e:
        raise ValueError("No se pudo abrir el Excel (.xlsx). Revisa el archivo.") from e
    filas, resp = [], {}
    for hoja in wb.worksheets:
        unidad, n = hoja.title.strip().upper(), 0
        encabezado_encontrado = False
        for r in hoja.iter_rows(values_only=True):
            r = list(r) + [None] * 14
            a = _t(r[0])
            if re.search("PLANILLA INVENTARIO", a, re.I):
                unidad = re.sub("PLANILLA INVENTARIO", "", a, flags=re.I).strip().upper() or unidad
                m = re.match(r"Responsable:\s*(.+)", _t(r[7]), re.I)
                if m: resp[unidad] = m.group(1).strip()
                continue
            if re.search(r"(?:N.?\s*ORDEN|ORDEN)", a, re.I) and "ITEM" in _t(r[1]).upper().replace("Í", "I"):
                encabezado_encontrado = True
                continue
            if not encabezado_encontrado or not _t(r[1]):
                continue
            # Las filas sin número de orden o con textos de cierre no son artículos.
            if not re.fullmatch(r"\d+(?:\.0)?", a):
                continue
            n += 1
            filas.append(dict(unidad=unidad, orden=_n(a) or n, item=_t(r[1]), marca=_t(r[2]), modelo=_t(r[3]),
                              serie=_t(r[4]), cantidad=_n(r[5]), ubicacion=_t(r[6]), estado=_t(r[7]),
                              origen=_t(r[8]), observaciones=_t(r[9]), vencimiento=_t(r[10]),
                              ultima_mantencion=_t(r[11]), cada_dias=_n(r[12]), valor_unitario=_n(r[13])))
    if not filas:
        raise ValueError("No se encontraron artículos válidos. Revisa los encabezados y números de orden.")
    return filas, resp

def importar(archivo, compania_id=1):
    """Reemplaza el inventario de las unidades que vienen en el archivo."""
    filas, resp = leer(archivo)
    conteo = {}
    with db.conn() as c:
        for f in filas: conteo[f["unidad"]] = conteo.get(f["unidad"], 0) + 1
        for u in conteo:
            perdida=c.execute("SELECT COUNT(*) FROM perdidas p JOIN items i ON p.item_id=i.id WHERE p.compania_id=? AND i.unidad=?",(compania_id,u)).fetchone()[0]
            if perdida: raise ValueError(f"No se puede reemplazar {u}: tiene pérdidas históricas registradas. Para conservar trazabilidad, edita los artículos desde el sistema.")
            c.execute("DELETE FROM items WHERE unidad=? AND compania_id=?", (u,compania_id))
        cols = list(filas[0].keys()) + ["compania_id"]
        for f in filas:
            c.execute(f"INSERT INTO items ({','.join(cols)}) VALUES ({','.join('?'*len(cols))})", [f[k] if k != "compania_id" else compania_id for k in cols])
        for u, r in resp.items():
            c.execute("INSERT INTO compania_unidades(compania_id,nombre,responsable) VALUES(?,?,?) ON CONFLICT(compania_id,nombre) DO UPDATE SET responsable=excluded.responsable", (compania_id, u, r))
    with db.conn() as c:
        for u in conteo:
            c.execute('INSERT OR IGNORE INTO compania_unidades(compania_id,nombre) VALUES(?,?)',(compania_id,u))
    return conteo

def sembrar_si_vacio():
    """Primera vez: carga los .xlsx de la carpeta datos/."""
    with db.conn() as c:
        if c.execute("SELECT COUNT(*) FROM items").fetchone()[0]: return
    for ruta in glob.glob(os.path.join(os.path.dirname(__file__), "datos", "*.xlsx")):
        importar(ruta)

def exportar(compania_id=1):
    wb = Workbook(); wb.remove(wb.active)
    with db.conn() as c:
        resp = {r["nombre"]: r["responsable"] for r in c.execute("SELECT nombre,responsable FROM compania_unidades WHERE compania_id=?",(compania_id,))}
        for u in [r[0] for r in c.execute("SELECT DISTINCT unidad FROM items WHERE compania_id=? ORDER BY 1",(compania_id,))]:
            ws = wb.create_sheet(re.sub(r"[\\/?*\[\]:]", "-", u)[:31])
            ws.append([f"PLANILLA INVENTARIO  {u}", "", "", "", "", "", "", f"Responsable: {resp[u]}" if resp.get(u) else ""])
            ws.append(ENCABEZADO)
            for n, i in enumerate(c.execute("SELECT * FROM items WHERE unidad=? AND compania_id=? ORDER BY orden", (u,compania_id)), 1):
                ws.append([n, i["item"], i["marca"], i["modelo"], i["serie"], i["cantidad"], i["ubicacion"], i["estado"],
                           i["origen"], i["observaciones"], i["vencimiento"], i["ultima_mantencion"], i["cada_dias"] or "",i["valor_unitario"]])
            for col, w in zip("ABCDEFGHIJKLMN", [9, 40, 16, 16, 18, 9, 12, 12, 26, 28, 13, 15, 11, 19]):
                ws.column_dimensions[col].width = w
    buf = BytesIO(); wb.save(buf); buf.seek(0)
    return buf
