/* Navegación visual independiente. No altera endpoints, datos ni las operaciones de Flask. */
const PANTALLAS = {
  inicio: ['Panel general', 'Inicio'],
  inventario: ['Inventario', 'Inventario'],
  'form-item': ['Ficha de artículo', 'Nuevo artículo'],
  alertas: ['Alertas', 'Alertas'],
  mantenimiento: ['Mantenciones', 'Mantenciones'],
  gastos: ['Gastos', 'Gastos'],
  checklist: ['Checklist diario', 'Checklist diario'],
  valorizacion: ['Valorización', 'Valorización'],
  perdidas: ['Pérdidas de inventario', 'Pérdidas'],
  administracion: ['Administración', 'Administración'],
};
let pantallaActiva = 'inicio';
let avisoTimeout;
function puedeVerPantalla(destino) {
  const rol = window.usuarioSesionRol;
  if (destino === 'administracion') return rol === 'admin';
  if (['form-item', 'valorizacion', 'perdidas', 'mantenimiento'].includes(destino)) return rol !== 'bombero';
  return true;
}
function irA(destino) {
  if (!PANTALLAS[destino] || !puedeVerPantalla(destino)) return;
  pantallaActiva = destino;
  document.querySelectorAll('.screen').forEach(el => {
    const activo = el.id === 'view-' + destino;
    el.classList.toggle('active', activo);
    el.setAttribute('aria-hidden', activo ? 'false' : 'true');
  });
  document.querySelectorAll('.nav-item[data-view]').forEach(el => {
    const activo = el.dataset.view === destino;
    el.classList.toggle('active', activo);
    if (activo) el.setAttribute('aria-current', 'page');
    else el.removeAttribute('aria-current');
  });
  document.getElementById('pageTitle').textContent = PANTALLAS[destino][0];
  document.getElementById('breadcrumbPage').textContent = PANTALLAS[destino][1].toUpperCase();
  cerrarMenu();
  window.scrollTo({ top: 0, behavior: 'auto' });
}
function nuevoArticulo() {
  if (!puedeVerPantalla('form-item')) return;
  resetForm();
  irA('form-item');
  document.getElementById('f_unidad').focus();
}
function mostrarAviso(mensaje) {
  const elemento = document.getElementById('toast');
  if (!elemento) return;
  elemento.textContent = mensaje;
  elemento.classList.add('visible');
  clearTimeout(avisoTimeout);
  avisoTimeout = setTimeout(() => elemento.classList.remove('visible'), 3800);
}
function abrirMenu() {
  document.getElementById('sidebar').classList.add('open');
  document.getElementById('sidebarOverlay').classList.add('open');
}
function cerrarMenu() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.remove('open');
}
function aplicarNavegacionRol(usuario, compania) {
  document.querySelectorAll('[data-role-admin]').forEach(el => { el.style.display = usuario.rol === 'admin' ? '' : 'none'; });
  document.querySelectorAll('[data-role-edit]').forEach(el => { el.style.display = usuario.rol === 'bombero' ? 'none' : ''; });
  document.querySelectorAll('.nav-item[data-view="mantenimiento"]').forEach(el => { el.style.display = usuario.rol === 'bombero' ? 'none' : ''; });
  const nombre = usuario.nombre || usuario.username || 'Usuario';
  document.getElementById('userAvatar').textContent = nombre.trim().slice(0, 1).toUpperCase();
  document.getElementById('usuarioActual').textContent = nombre;
  document.getElementById('usuarioRol').textContent = ({admin:'Administrador',encargado:'Encargado',bombero:'Bombero'})[usuario.rol] || usuario.rol;
  document.getElementById('companiaCabecera').textContent = compania?.nombre || 'Compañía activa';
  const banner = document.querySelector('.welcome-banner h2');
  if (banner) banner.innerHTML = 'Bienvenido al panel de control<span class="accent-dot">.</span>';
  if (!puedeVerPantalla(pantallaActiva)) irA('inicio');
}
function verAlerta(id) {
  const item = items.find(x => x.id === id);
  if (!item) return;
  if (window.usuarioSesionRol !== 'bombero') {
    edit(id);
  } else {
    irA('inventario');
    const buscador = document.getElementById('q');
    buscador.value = item.item;
    render();
  }
}
document.addEventListener('keydown', ev => { if (ev.key === 'Escape') cerrarMenu(); });
irA('inicio');
